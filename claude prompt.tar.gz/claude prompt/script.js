
    document.addEventListener('DOMContentLoaded', () => {
        // --- البيانات التجريبية للهواتف ---
        const phonesData = [
            {
                id: 1,
                name: 'iPhone 15 Pro Max',
                manufacturer: 'Apple',
                price: 230000,
                rating: 4.9,
                releaseDate: '2023-09-22',
                image: 'https://www.apple.com/v/iphone-15-pro/c/images/overview/design/design_display_pro_max__f6a9jyx2e76e_large.jpg',
                specs: {
                    ram: 8,
                    storage: 256,
                    camera: { front: '12MP', back: '48MP' },
                    os: 'iOS 17',
                    cpu: 'A17 Pro',
                    battery: 4422,
                    screen: '6.7"',
                    water_resistance: 'IP68'
                }
            },
            {
                id: 2,
                name: 'Galaxy S24 Ultra',
                manufacturer: 'Samsung',
                price: 200000,
                rating: 4.8,
                releaseDate: '2024-01-25',
                image: 'https://images.samsung.com/is/image/samsung/p6pim/sa_en/2401/gallery/sa_en-galaxy-s24-ultra-sm-s928-493063-sm-s928bztqmea-thumb-539572230?$344_344_PNG$',
                specs: {
                    ram: 12,
                    storage: 512,
                    camera: { front: '12MP', back: '200MP' },
                    os: 'Android 14',
                    cpu: 'Snapdragon 8 Gen 3',
                    battery: 5000,
                    screen: '6.8"',
                    water_resistance: 'IP68'
                }
            },
            {
                id: 3,
                name: 'Xiaomi 14',
                manufacturer: 'Xiaomi',
                price: 130000,
                rating: 4.7,
                releaseDate: '2023-10-26',
                image: 'https://i01.appmifile.com/v1/MI_18455B3E4DA706226CF7535A58E875F0/pms_1698215304.1573641.png',
                specs: {
                    ram: 12,
                    storage: 256,
                    camera: { front: '32MP', back: '50MP' },
                    os: 'Android 14',
                    cpu: 'Snapdragon 8 Gen 3',
                    battery: 4610,
                    screen: '6.36"',
                    water_resistance: 'IP68'
                }
            },
            {
                id: 4,
                name: 'Google Pixel 8 Pro',
                manufacturer: 'Google',
                price: 130000,
                rating: 4.6,
                releaseDate: '2023-10-12',
                image: 'https://storage.googleapis.com/gweb-uniblog-publish-prod/images/group_2_ALTA_2.width-1000.height-1000.format-webp.webp',
                specs: {
                    ram: 12,
                    storage: 256,
                    camera: { front: '10.5MP', back: '50MP' },
                    os: 'Android 14',
                    cpu: 'Google Tensor G3',
                    battery: 5050,
                    screen: '6.7"',
                    water_resistance: 'IP68'
                }
            },
        ];

        // --- عناصر DOM ---
        const phonesGrid = document.getElementById('phones-grid');
        const searchBar = document.getElementById('search-bar');
        const manufacturerFilter = document.getElementById('manufacturer-filter');
        const priceSlider = document.getElementById('price-slider');
        const priceValue = document.getElementById('price-value');
        const ramFilters = document.querySelectorAll('#ram-filter input[type="checkbox"]');
        const storageFilters = document.querySelectorAll('#storage-filter input[type="checkbox"]');
        const sortOptions = document.getElementById('sort-options');
        const phoneCount = document.getElementById('phone-count');
        
        // Modal elements
        const modal = document.getElementById('quick-view-modal');
        const closeModalBtn = document.querySelector('.close-btn');
        const modalPhoneName = document.getElementById('modal-phone-name');
        const modalManufacturer = document.getElementById('modal-manufacturer');
        const modalRating = document.getElementById('modal-rating');
        const modalPrice = document.getElementById('modal-price');
        const modalImage = document.getElementById('main-modal-image');
        const modalSpecsTable = document.getElementById('modal-specs-table');

        let currentFilters = {
            searchTerm: '',
            manufacturers: [],
            maxPrice: 800000,
            ram: [],
            storage: []
        };

        // --- عرض الهواتف ---
        function displayPhones(phoneList) {
            phonesGrid.innerHTML = '';
            if (phoneList.length === 0) {
                phonesGrid.innerHTML = '<p>لا توجد هواتف تطابق بحثك.</p>';
                phoneCount.textContent = '0 هاتف';
                return;
            }

            phoneList.forEach(phone => {
                const card = document.createElement('div');
                card.className = 'phone-card';
                card.innerHTML = `
                    <img src="${phone.image}" alt="${phone.name}" class="phone-card-img">
                    <div class="phone-card-content">
                        <h4>${phone.name}</h4>
                        <p class="manufacturer">${phone.manufacturer}</p>
                        <div class="rating">${'★'.repeat(Math.round(phone.rating))}${'☆'.repeat(5 - Math.round(phone.rating))}</div>
                        <div class="price">${phone.price} دينار جزائري</div>
                        <div class="specs-preview">
                            <span><i class="fas fa-memory"></i> ${phone.specs.ram}GB</span>
                            <span><i class="fas fa-hdd"></i> ${phone.specs.storage}GB</span>
                            <span><i class="fas fa-camera"></i> ${phone.specs.camera.back}</span>
                        </div>
                        <button class="details-btn" data-id="${phone.id}">عرض التفاصيل</button>
                    </div>
                `;
                phonesGrid.appendChild(card);
            });
            phoneCount.textContent = `${phoneList.length} هاتف`;
            
            // Add event listeners for the new buttons
            document.querySelectorAll('.details-btn').forEach(button => {
                button.addEventListener('click', () => openQuickView(button.dataset.id));
            });
        }

        // --- ملء الفلاتر ---
        function populateFilters() {
            const manufacturers = [...new Set(phonesData.map(p => p.manufacturer))];
            manufacturerFilter.innerHTML = '<li><label><input type="checkbox" value="all" checked> الكل</label></li>';
            manufacturers.forEach(m => {
                manufacturerFilter.innerHTML += `<li><label><input type="checkbox" value="${m}"> ${m}</label></li>`;
            });
            
            // Add event listeners for manufacturer filters
            document.querySelectorAll('#manufacturer-filter input').forEach(checkbox => {
                checkbox.addEventListener('change', handleFilterChange);
            });
        }

        // --- تطبيق الفلاتر والبحث ---
        function applyFiltersAndSort() {
            let filteredPhones = [...phonesData];

            // وظيفة مساعدة للبحث العميق في المواصفات
            const deepSearch = (obj, term) => {
                for (let key in obj) {
                    const value = obj[key];
                    if (typeof value === 'object' && value !== null) {
                        if (deepSearch(value, term)) return true;
                    } else if (String(value).toLowerCase().includes(term)) {
                        return true;
                    }
                }
                return false;
            };

            // Search term
            if (currentFilters.searchTerm) {
                const term = currentFilters.searchTerm.toLowerCase();
                filteredPhones = filteredPhones.filter(p => 
                    p.name.toLowerCase().includes(term) ||
                    p.manufacturer.toLowerCase().includes(term) ||
                    deepSearch(p.specs, term)
                );
            }

            // Manufacturer
            if (currentFilters.manufacturers.length > 0) {
                filteredPhones = filteredPhones.filter(p => currentFilters.manufacturers.includes(p.manufacturer));
            }

            // Price
            filteredPhones = filteredPhones.filter(p => p.price <= currentFilters.maxPrice);

            // RAM
            if (currentFilters.ram.length > 0) {
                filteredPhones = filteredPhones.filter(p => {
                    if (currentFilters.ram.includes('16')) {
                        return p.specs.ram >= 16 || currentFilters.ram.includes(String(p.specs.ram));
                    }
                    return currentFilters.ram.includes(String(p.specs.ram));
                });
            }

            // Storage
            if (currentFilters.storage.length > 0) {
                filteredPhones = filteredPhones.filter(p => currentFilters.storage.includes(String(p.specs.storage)));
            }

            // Sorting
            const sortBy = sortOptions.value;
            if (sortBy === 'price-asc') {
                filteredPhones.sort((a, b) => a.price - b.price);
            } else if (sortBy === 'price-desc') {
                filteredPhones.sort((a, b) => b.price - a.price);
            } else if (sortBy === 'rating') {
                filteredPhones.sort((a, b) => b.rating - a.rating);
            } else if (sortBy === 'newest') {
                filteredPhones.sort((a, b) => new Date(b.releaseDate) - new Date(a.releaseDate));
            }

            displayPhones(filteredPhones);
        }

        // --- معالجة تغيير الفلاتر ---
        function handleFilterChange(event) {
            const allManufacturersCheckbox = document.querySelector('#manufacturer-filter input[value="all"]');
            const manufacturerCheckboxes = document.querySelectorAll('#manufacturer-filter input:not([value="all"])');

            // Search
            currentFilters.searchTerm = searchBar.value;

            // Manufacturers
            if (event && event.target.type === 'checkbox' && event.target.parentElement.parentElement.id === 'manufacturer-filter') {
                const changedCheckbox = event.target;
                if (changedCheckbox.value === 'all') {
                    // إذا تم تحديد "الكل"، قم بإلغاء تحديد الآخرين
                    if (changedCheckbox.checked) {
                        manufacturerCheckboxes.forEach(cb => cb.checked = false);
                    }
                } else {
                    // إذا تم تحديد خيار آخر، قم بإلغاء تحديد "الكل"
                    allManufacturersCheckbox.checked = false;
                }
                
                // إذا لم يتم تحديد أي خيار، حدد "الكل"
                const anyChecked = Array.from(manufacturerCheckboxes).some(cb => cb.checked);
                if (!anyChecked && !allManufacturersCheckbox.checked) {
                    allManufacturersCheckbox.checked = true;
                }
            }
            
            if (allManufacturersCheckbox.checked) {
                currentFilters.manufacturers = [];
            } else {
                currentFilters.manufacturers = Array.from(document.querySelectorAll('#manufacturer-filter input:not([value="all"]):checked')).map(cb => cb.value);
            }

            // Price
            currentFilters.maxPrice = parseInt(priceSlider.value);
            priceValue.textContent = `حتى ${currentFilters.maxPrice} دينار جزائري`;

            // RAM
            currentFilters.ram = Array.from(ramFilters).filter(cb => cb.checked).map(cb => cb.value);
            
            // Storage
            currentFilters.storage = Array.from(storageFilters).filter(cb => cb.checked).map(cb => cb.value);

            applyFiltersAndSort();
        }
        
        // --- نافذة العرض السريع ---
        function openQuickView(phoneId) {
            const phone = phonesData.find(p => p.id == phoneId);
            if (!phone) return;

            modalPhoneName.textContent = phone.name;
            modalManufacturer.textContent = phone.manufacturer;
            modalRating.innerHTML = `${'★'.repeat(Math.round(phone.rating))}${'☆'.repeat(5 - Math.round(phone.rating))} (${phone.rating})`;
            modalPrice.textContent = `${phone.price} دينار جزائري`;
            modalImage.src = phone.image;
            
            modalSpecsTable.innerHTML = `
                <tr><td>نظام التشغيل</td><td>${phone.specs.os}</td></tr>
                <tr><td>المعالج</td><td>${phone.specs.cpu}</td></tr>
                <tr><td>الذاكرة (RAM)</td><td>${phone.specs.ram} GB</td></tr>
                <tr><td>التخزين</td><td>${phone.specs.storage} GB</td></tr>
                <tr><td>الكاميرا الخلفية</td><td>${phone.specs.camera.back}</td></tr>
                <tr><td>الكاميرا الأمامية</td><td>${phone.specs.camera.front}</td></tr>
                <tr><td>البطارية</td><td>${phone.specs.battery} mAh</td></tr>
                <tr><td>الشاشة</td><td>${phone.specs.screen}</td></tr>
                <tr><td>مقاومة الماء</td><td>${phone.specs.water_resistance}</td></tr>
            `;

            modal.style.display = 'block';
        }

        function closeModal() {
            modal.style.display = 'none';
        }

        // --- ربط الأحداث ---
        searchBar.addEventListener('input', handleFilterChange);
        priceSlider.addEventListener('input', handleFilterChange);
        ramFilters.forEach(cb => cb.addEventListener('change', handleFilterChange));
        storageFilters.forEach(cb => cb.addEventListener('change', handleFilterChange));
        sortOptions.addEventListener('change', applyFiltersAndSort);
        
        closeModalBtn.addEventListener('click', closeModal);
        window.addEventListener('click', (event) => {
            if (event.target == modal) {
                closeModal();
            }
        });

        // --- التشغيل الأولي ---
        populateFilters();
        applyFiltersAndSort();
    });